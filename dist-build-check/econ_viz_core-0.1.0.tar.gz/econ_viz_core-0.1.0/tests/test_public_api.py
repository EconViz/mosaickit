import subprocess
import sys
from importlib.metadata import version
from pathlib import Path

import econ_viz_core


def test_public_exports_and_typing_marker():
    assert econ_viz_core.__version__ == version("econ-viz-core")
    assert Path(econ_viz_core.__file__).with_name("py.typed").is_file()
    assert all(hasattr(econ_viz_core, name) for name in econ_viz_core.__all__)
    for name in ("_RenderContext", "_RenderPlan", "_ResolvedLayer", "AxesLayer"):
        assert not hasattr(econ_viz_core, name)


def test_root_import_does_not_load_matplotlib_or_domain_packages():
    result = subprocess.run(
        [
            sys.executable,
            "-c",
            "import sys; import econ_viz_core; "
            "assert 'matplotlib' not in sys.modules; "
            "assert 'econ_viz' not in sys.modules",
        ],
        capture_output=True,
        text=True,
    )
    assert result.returncode == 0, result.stderr
