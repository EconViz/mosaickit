from econ_viz_core.errors import RenderError
from econ_viz_core.rendering.protocol import Renderer


class RendererRegistry:
    def __init__(self) -> None:
        self._renderers: dict[str, Renderer] = {}

    def register(self, renderer: Renderer) -> None:
        if not isinstance(renderer, Renderer):
            raise RenderError("Renderer must implement name, render, and save")
        if renderer.name in self._renderers:
            raise RenderError(f"Renderer already registered: {renderer.name!r}")
        self._renderers[renderer.name] = renderer

    def get(self, name: str) -> Renderer:
        if name in self._renderers:
            return self._renderers[name]
        if name == "matplotlib":
            from econ_viz_core.rendering.matplotlib import MatplotlibRenderer

            return MatplotlibRenderer()
        if name == "tikz":
            from econ_viz_core.rendering.tikz import TikzRenderer

            return TikzRenderer()
        raise RenderError(f"Unknown renderer: {name!r}")
