"""Domain-neutral diagram construction and rendering."""

from econ_viz_core.canvas import Animation, Canvas, CanvasGrid, Layout, Span
from econ_viz_core.canvas_spec import CanvasSpec
from econ_viz_core.colors import TRANSPARENT, Color
from econ_viz_core.config import Config, use_config
from econ_viz_core.errors import BindingError, ConfigurationError, EconVizCoreError, RenderError
from econ_viz_core.interval import Interval
from econ_viz_core.parameter import Constant, Expression, Parameter, ParameterValues
from econ_viz_core.rendering import (
    CacheBypassWarning,
    CacheKey,
    RenderCache,
    Renderer,
    RendererRegistry,
    SaveOptions,
)
from econ_viz_core.scene import (
    ArrowLayer,
    AxisSpec,
    FillLayer,
    GroupLayer,
    Layer,
    LegendLayer,
    MarkerLayer,
    PathLayer,
    Scene,
    TextLayer,
    box_frame,
    build_axes,
    crosshair_axes,
    quadrant_axes,
)
from econ_viz_core.styles import (
    ArrowPlacement,
    ArrowStyle,
    DashStyle,
    Fill,
    LegendStyle,
    Marker,
    SparseStyle,
    Stroke,
    TextStyle,
)
from econ_viz_core.themes import RolePack, StyleBundle, Theme, ThemeRegistry, expand_roles

__version__ = "0.1.0"
__all__ = [
    "Animation",
    "ArrowLayer",
    "ArrowPlacement",
    "ArrowStyle",
    "AxisSpec",
    "BindingError",
    "CacheBypassWarning",
    "CacheKey",
    "Canvas",
    "CanvasGrid",
    "CanvasSpec",
    "Color",
    "Config",
    "ConfigurationError",
    "Constant",
    "DashStyle",
    "EconVizCoreError",
    "Expression",
    "Fill",
    "FillLayer",
    "GroupLayer",
    "Interval",
    "Layer",
    "Layout",
    "LegendLayer",
    "LegendStyle",
    "Marker",
    "MarkerLayer",
    "Parameter",
    "ParameterValues",
    "PathLayer",
    "RenderCache",
    "RenderError",
    "Renderer",
    "RendererRegistry",
    "RolePack",
    "SaveOptions",
    "Scene",
    "Span",
    "SparseStyle",
    "Stroke",
    "StyleBundle",
    "TRANSPARENT",
    "TextLayer",
    "TextStyle",
    "Theme",
    "ThemeRegistry",
    "__version__",
    "box_frame",
    "build_axes",
    "crosshair_axes",
    "expand_roles",
    "quadrant_axes",
    "use_config",
]
