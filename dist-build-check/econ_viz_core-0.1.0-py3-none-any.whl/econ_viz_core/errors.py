"""Public exception hierarchy."""


class EconVizCoreError(Exception):
    """Base error for core operations."""


class ConfigurationError(EconVizCoreError, ValueError):
    """An invalid model or configuration value."""


class RenderError(EconVizCoreError, RuntimeError):
    """A renderer cannot perform the requested operation."""


class BindingError(EconVizCoreError, ValueError):
    """A parameter cannot be bound or evaluated."""
