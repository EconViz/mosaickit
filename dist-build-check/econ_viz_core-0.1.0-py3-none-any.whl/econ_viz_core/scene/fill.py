from dataclasses import dataclass, field
from typing import Any, ClassVar

from econ_viz_core.scene.layer import Layer, _geometry
from econ_viz_core.styles import Fill, Stroke


@dataclass(frozen=True, slots=True)
class FillLayer(Layer):
    role: str = field(default="region", kw_only=True)
    boundary: Any
    fill: Fill | None = None
    stroke: Stroke | None = None
    fallback_category: ClassVar[str] = "region"

    def __post_init__(self) -> None:
        Layer.__post_init__(self)
        object.__setattr__(self, "boundary", _geometry(self.boundary, minimum=3))
